% SequenceReaderP   Classe de lecture de fichiers .hcc utilisant memmapfile.
%%   Reference page in Doc Center
%      doc SequenceReaderP
%%
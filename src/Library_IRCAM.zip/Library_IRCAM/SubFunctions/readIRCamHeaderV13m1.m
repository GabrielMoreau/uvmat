% Decode header portion of an IRCam image.
%   Header = readIRCamHeaderV13m1(bytes)
%
%   INPUT
%     bytes: an array of headers in uint8 (byte) format <Nframes x Nbytes>
%
%   auto-generated function for header decoding.
%   based on Excel header file definition version 13.1
%
%   DO NOT MANUALLY MODIFIY THIS CODE!
%   Modify the generateIRCamHeaderMatlabLib.m script instead.
%